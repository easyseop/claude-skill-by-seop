# v1.2 → v1.3 마이그레이션

## 신규 파일

```text
SOURCE_DECISIONS.md
REQUIREMENT_INTAKE.yaml
DESIGN_AUDIT_ATTESTATION.yaml
AUDIT_ATTESTATION.yaml
AUTHORING_STATE.yaml
scripts/seal_attestation.py
```

## 기존 진행 중 작업

1. 기존 `SOURCE_REQUEST.md`를 최초 원문으로 간주하고 v1.3 최초 `init_authoring.py --resume` 시 잠근다.
2. 기존 파일에 섞인 후속 결정을 `SOURCE_DECISIONS.md`로 이동한다. 원문과 후속 결정을 명확히 분리할 수 없으면 새 target 또는 `--reset`으로 다시 intake한다.
3. `REQUIREMENT_INTAKE.yaml`을 작성하고 모든 명시 요구를 DESIGN 섹션에 연결한다.
4. 새 설계 감사자를 실행한 뒤 `seal_attestation.py --kind design`을 실행한다.
5. design → spec → build → audit을 순서대로 재검증한다.
6. 최종 감사 PASS 후 `seal_attestation.py --kind final`을 실행한다.

v1.2의 과거 PASS JSON은 v1.3 fingerprint로 재사용하지 않는다.
