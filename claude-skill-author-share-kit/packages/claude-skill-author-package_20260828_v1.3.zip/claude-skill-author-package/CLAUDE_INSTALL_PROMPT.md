# Claude Code에 전달할 v1.3 일괄 설치 지시문

현재 Claude Code가 열린 Git 저장소 루트에 있는 `claude-skill-author-package_20260828_v1.3.zip`을 설치하라.

1. `git rev-parse --show-toplevel`과 `git status --short`로 저장소 루트와 기존 변경을 확인한다.
2. ZIP이 저장소 루트에 없으면 다른 경로를 추측하거나 다운로드하지 말고 중단한다.
3. 시스템 임시 디렉터리에 압축을 해제한다.
4. `INSTALL.md`, `install.sh`, `tests/run_tests.py`, 메타 스킬 `SKILL.md`, 네 Python 스크립트와 세 에이전트 정의를 읽는다.
5. 설치 범위가 현재 저장소 `.claude/` 하위인지, 네트워크·Git 쓰기·제품 코드 수정이 없는지, 기존 파일을 백업하는지, `.claude/settings.json`을 자동 수정하지 않는지 확인한다.
6. 이상이 없으면 패키지 디렉터리에서 `python3 tests/run_tests.py`를 실행한다.
7. 테스트 종료코드가 0일 때만 `./install.sh "$(git rev-parse --show-toplevel)"`을 실행한다.
8. 다음을 검증한다.
   - `.claude/skills/claude-skill-author/SKILL.md`
   - `assets/SOURCE_REQUEST.template.md`
   - `assets/SOURCE_DECISIONS.template.md`
   - `assets/REQUIREMENT_INTAKE.template.yaml`
   - `assets/DESIGN_INPUT.template.md`
   - `scripts/init_authoring.py`
   - `scripts/validate_authoring.py`
   - `scripts/seal_attestation.py`
   - `scripts/stop_gate.py`
   - `.claude/agents/skill-design-author.md`
   - `.claude/agents/skill-design-auditor.md`
   - `.claude/agents/skill-author-auditor.md`
9. 모든 Python 스크립트에 `python3 -m py_compile`을 실행하고 `git diff -- .claude`를 확인한다.
10. Stop 훅 예시는 자동 활성화하지 않는다.
11. 커밋·푸시는 수행하지 않는다.

최종 보고에는 설치 성공 여부, 생성·백업 경로, 패키지 테스트, Python 구문 검사, 예상 밖 변경 여부, 재시작 필요 여부만 적는다. 이번 요청에서는 대상 업무 스킬을 생성하지 않는다.
