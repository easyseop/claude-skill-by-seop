# Claude Skill Author v1.3 설치와 사용

## 설치되는 구성

```text
.claude/skills/claude-skill-author/
├── SKILL.md
├── assets/
│   ├── SOURCE_REQUEST.template.md
│   ├── SOURCE_DECISIONS.template.md
│   ├── REQUIREMENT_INTAKE.template.yaml
│   ├── DESIGN_INPUT.template.md
│   ├── DESIGN_REQUIREMENTS.template.yaml
│   ├── DESIGN_AUDIT_REPORT.template.md
│   ├── DESIGN_AUDIT_ATTESTATION.template.yaml
│   ├── AUDIT_ATTESTATION.template.yaml
│   ├── AUTHORING_STATE.template.yaml
│   ├── TARGET_AGENT.template.md
│   └── 작성·감사 템플릿
├── references/
│   ├── requirements-elicitation.md
│   ├── design-input-guide.md
│   ├── authoring-workflow.md
│   ├── schemas.md
│   └── 작성·감사 규칙
└── scripts/
    ├── init_authoring.py
    ├── validate_authoring.py
    ├── seal_attestation.py
    └── stop_gate.py

.claude/agents/skill-design-author.md
.claude/agents/skill-design-auditor.md
.claude/agents/skill-author-auditor.md
.claude/settings.stop-hook.example.json
```

## v1.3의 추가 게이트

```text
최초 자연어 원문 불변 보존
→ 후속 결정 분리
→ REQUIREMENT_INTAKE 원자 요구사항 추적
→ DESIGN 20개 섹션 검사
→ DESIGN_REQUIREMENTS 18개 항목 검사
→ 독립 설계 감사 digest attestation
→ design PASS
→ spec → build
→ 독립 최종 감사 digest attestation
→ audit PASS
→ FINAL_STATUS PASS
```

이전 PASS 이후 원문·결정·설계·명세·런타임 파일이 변경되면 뒤 단계가 `STALE`이 되어 재검증을 요구한다.

## 설치

```bash
./install.sh /path/to/repository
```

현재 디렉터리가 대상 저장소면:

```bash
./install.sh .
```

기존 파일은 `.bak-<UTC시각>`으로 백업한다. `.claude/settings.json`은 수정하지 않으며 Stop 훅은 예시 파일로만 설치한다.

## 자연어 한 번으로 스킬 만들기

```text
/claude-skill-author evidence-code-review --mode full --agent auto

코드 리뷰 중 파일을 직접 수정하지 못하게 하고 싶다.
모든 지적에는 파일·줄 번호·코드 근거가 있어야 한다.
로컬 테스트 실행은 허용하지만, 실행하지 못한 검사는 통과로 표시하지 않는다.
커밋과 푸시는 금지한다.
```

설계서가 없으면 기본 경로에 생성한다.

```text
docs/skill-designs/evidence-code-review/DESIGN.md
```

작성 증거:

```text
.claude/skill-authoring/evidence-code-review/
```

## 모드

- `design`: 원문 보존·요구사항 intake·설계·설계 감사
- `spec`: design 포함, 규칙 판정·명세까지
- `build`: 승인된 명세로 런타임 파일 작성
- `audit`: 최종 읽기 전용 감사
- `full`: 전체 과정

## Agent.md 정책

```text
--agent auto
--agent required
--agent forbidden
```

## 선택적 Stop 훅

`.claude/settings.stop-hook.example.json`을 기존 설정에 자동 병합하지 않는다. 보안·충돌을 검토한 후 `hooks.Stop` 부분만 수동 병합한다. 활성화 시 Stop 훅은 이전 PASS 표시를 신뢰하지 않고 필요한 최종 검증을 다시 실행해 fingerprint freshness를 확인한다.

## 테스트

```bash
python3 tests/run_tests.py
```
