# Claude Skill Author v1.3 추가개발 결과

## 개발 근거

성공 실행 재구성에서 확인된 공백을 패키지 본체의 결정적 게이트로 이동했다.

| 공백 | v1.3 구현 |
|---|---|
| G1 최초 자연어 원문 미보존 | `SOURCE_REQUEST.md` 불변 잠금과 SHA-256 검사 |
| G2 원문→설계 독립 감사 부재 | `REQUIREMENT_INTAKE.yaml`, `skill-design-auditor`, 설계 audit attestation |
| G3 설계 선완성 기계 게이트 부재 | `--phase design`, DESIGN 20섹션·18요구·digest 검증 |

## 추가 보강

- 후속 사용자 결정은 `SOURCE_DECISIONS.md`에 분리·누적
- 원자 요구사항 `REQ-###` 추적과 blocking 질문 게이트
- `AUTHORING_STATE.yaml`의 design/spec/build/audit 상태 머신
- 이전 PASS 후 입력 변경 시 뒤 단계 `STALE` 무효화
- 최종 감사도 `AUDIT_ATTESTATION.yaml`로 현재 런타임 파일에 결합
- Stop 훅은 PASS 표시가 아니라 필요한 최종 검증을 다시 실행
- Agent.md 자동 필요성 판정은 기존 정책 유지

## 보수적 기본 결정

- 최초 원문은 수정 금지. 변경 요구는 후속 결정 파일에 기록한다.
- 권한·운영·삭제·배포·외부 전송은 안전한 기본값으로 추측하지 않는다.
- 설계 감사와 최종 감사는 모두 독립 읽기 전용 역할이 담당한다.
- Stop 훅은 자동 활성화하지 않는다.
- `--agent auto`를 기본으로 하되 단순 슬래시 스킬에는 Agent.md를 만들지 않는다.

## 검증

패키지 테스트에서 다음 반례를 확인했다.

- 미해결 설계 요구사항 차단
- PASS 문구만 있고 attestation이 없으면 차단
- 20개 설계 섹션 중 하나 삭제 시 차단
- 설계 PASS 이후 DESIGN.md 수정 시 audit 차단
- 후속 결정 추가 시 design 이후 단계 STALE
- 최초 SOURCE_REQUEST 변조 후 resume 차단
- 최종 PASS 보고서만 있고 final attestation이 없으면 차단
- 동일 입력 resume은 기존 PASS freshness 유지
- 기존 89규칙·26안티패턴·9단계 모듈 회귀 통과
