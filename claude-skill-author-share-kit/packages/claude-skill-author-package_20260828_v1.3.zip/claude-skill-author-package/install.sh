#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="$(cd "${1:-.}" && pwd)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"

copy_with_backup() {
  local src="$1"
  local dst="$2"
  if [[ -e "$dst" ]]; then
    mv "$dst" "${dst}.bak-${STAMP}"
  fi
  mkdir -p "$(dirname "$dst")"
  cp -R "$src" "$dst"
}

copy_with_backup \
  "$SCRIPT_DIR/.claude/skills/claude-skill-author" \
  "$TARGET_ROOT/.claude/skills/claude-skill-author"

for agent in skill-design-author.md skill-design-auditor.md skill-author-auditor.md; do
  copy_with_backup \
    "$SCRIPT_DIR/.claude/agents/$agent" \
    "$TARGET_ROOT/.claude/agents/$agent"
done

if [[ ! -e "$TARGET_ROOT/.claude/settings.stop-hook.example.json" ]]; then
  cp "$SCRIPT_DIR/.claude/settings.stop-hook.example.json" \
     "$TARGET_ROOT/.claude/settings.stop-hook.example.json"
fi

printf 'Installed:\n- %s\n' "$TARGET_ROOT/.claude/skills/claude-skill-author"
printf '%s\n' \
  "- $TARGET_ROOT/.claude/agents/skill-design-author.md" \
  "- $TARGET_ROOT/.claude/agents/skill-design-auditor.md" \
  "- $TARGET_ROOT/.claude/agents/skill-author-auditor.md"
printf '\nInvoke with: /claude-skill-author <skill-name> --mode full [natural-language requirements]\n'
