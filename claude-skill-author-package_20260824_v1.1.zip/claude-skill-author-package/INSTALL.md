# Claude Skill Author 설치와 사용

## 설치되는 구성

```text
.claude/skills/claude-skill-author/
├── SKILL.md
├── assets/
│   ├── DESIGN_INPUT.template.md
│   ├── DESIGN_REQUIREMENTS.template.yaml
│   └── ...
├── references/
│   ├── design-input-guide.md
│   └── ...
└── scripts/
    ├── init_authoring.py
    ├── validate_authoring.py
    └── stop_gate.py

.claude/agents/skill-author-auditor.md
.claude/settings.stop-hook.example.json
```

공통 규칙, Claude Code 전용 규칙, 설계서 입력 템플릿, 규칙 전수 판정, 기계 검증, 독립 감사 절차가 함께 설치된다.

## 패키지 디렉터리에서 설치

```bash
./install.sh /path/to/your/repository
```

현재 디렉터리가 대상 저장소면 다음처럼 실행한다.

```bash
./install.sh .
```

기존 파일이 있으면 덮어쓰기 전에 `.bak-<UTC시각>`으로 백업한다. `.claude/settings.json`은 수정하지 않으며 Stop 훅은 예시 파일로만 둔다.

## ZIP을 저장소 루트에 둔 상태에서 한 번에 설치

```bash
PROJECT_ROOT="$(git rev-parse --show-toplevel)" && \
ZIP="$PROJECT_ROOT/claude-skill-author-package_20260824_v1.1.zip" && \
TMP="$(mktemp -d)" && \
unzip -q "$ZIP" -d "$TMP" && \
cd "$TMP/claude-skill-author-package" && \
python3 tests/run_tests.py && \
chmod +x install.sh && \
./install.sh "$PROJECT_ROOT"
```

`unzip`이 없으면 Python 표준 라이브러리 `zipfile`로 압축을 해제한다. 설치 후 Claude Code를 완전히 종료하고 같은 저장소 루트에서 다시 실행하는 것이 안전하다.

## 설계서 작성

새 설계서는 설치된 다음 파일을 기준으로 작성한다.

```text
.claude/skills/claude-skill-author/assets/DESIGN_INPUT.template.md
```

설계서는 자유 형식이어도 되지만 다음 의미 항목이 모두 필요하다.

- 목적과 사용자 결과
- 사용·비사용 시점과 호출 예
- 입력·기본값·출처 경계
- 포함·제외·조건부 범위
- 허용·금지·승인 행동
- 단계별 절차와 출력
- 검증·시나리오
- 실패·재시도·중단·복구
- 완료 조건

메타 스킬은 이를 `.claude/skill-authoring/<target>/DESIGN_REQUIREMENTS.yaml`로 구조화한다. 모든 필수 항목이 `RESOLVED`이고 근거 출처가 연결되지 않으면 `COMMAND_SPEC.yaml`을 승인하거나 `SKILL.md`를 작성하지 않는다.

## 기본 사용

```text
/claude-skill-author omplan --mode full \
  --design docs/openmetadata/OM_PLAN_DESIGN.md \
  --design docs/openmetadata/governance_requirements.md

목적: OpenMetadata 변경 전에 검증 가능한 실행계획을 작성한다.
허용: 문서·저장소 읽기와 계획 문서 작성.
금지: 제품 코드 수정, 커밋, 푸시, 배포.
```

한 번의 호출로 다음이 진행된다.

```text
설계 요구사항 구조화·검증
→ 규칙 자동 추출
→ 모든 규칙 전수 판정
→ COMMAND_SPEC 확정
→ SKILL.md 작성
→ 기계 검증
→ 새 감사자 인스턴스의 읽기 전용 감사
→ 최종 PASS 게이트
```

## 모드별 사용

```text
/claude-skill-author omplan --mode spec --design docs/openmetadata/OM_PLAN_DESIGN.md
/claude-skill-author omplan --mode build
/claude-skill-author omplan --mode audit
```

## 생성 위치

런타임 스킬:

```text
.claude/skills/<target>/
```

작성·감사 증거:

```text
.claude/skill-authoring/<target>/
├── DESIGN_REQUIREMENTS.yaml
├── RULE_MANIFEST.yaml
├── COMMAND_SPEC.yaml
├── RULE_COVERAGE.yaml
└── ...
```

## 선택적 Stop 훅

`.claude/settings.stop-hook.example.json`은 작성 검증이 실패한 상태에서 Claude가 작업을 끝내지 못하도록 하는 예시다. 기존 `.claude/settings.json`에 덮어쓰지 말고 `hooks.Stop` 항목만 별도 보안 검토 후 병합한다.

## 테스트

```bash
python3 tests/run_tests.py
```
