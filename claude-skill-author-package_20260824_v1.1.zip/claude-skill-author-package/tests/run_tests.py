#!/usr/bin/env python3
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[1]
SKILL = PACKAGE / ".claude" / "skills" / "claude-skill-author"
INIT = SKILL / "scripts" / "init_authoring.py"
VALIDATE = SKILL / "scripts" / "validate_authoring.py"
COMMON = SKILL / "references" / "01_LLM_스킬_하네스_MD_공통_작성규칙.md"
CLAUDE = SKILL / "references" / "02_Claude_Code_슬래시커맨드_MD_차이점_전용규칙.md"
DESIGN_TEMPLATE = SKILL / "assets" / "DESIGN_INPUT.template.md"
DESIGN_REQUIREMENTS_TEMPLATE = SKILL / "assets" / "DESIGN_REQUIREMENTS.template.yaml"
DESIGN_GUIDE = SKILL / "references" / "design-input-guide.md"


def run(cmd: list[str], expected: int = 0) -> subprocess.CompletedProcess[str]:
    p = subprocess.run(cmd, text=True, capture_output=True)
    if p.returncode != expected:
        print(p.stdout)
        print(p.stderr, file=sys.stderr)
        raise AssertionError(f"expected exit {expected}, got {p.returncode}: {cmd}")
    return p


def dump(path: Path, data: object) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        design = root / "design.md"
        design.write_text("# Design\nCreate a planning skill.\n", encoding="utf-8")
        run([
            sys.executable, str(INIT),
            "--project-root", str(root),
            "--target", "test-skill",
            "--mode", "full",
            "--common-rules", str(COMMON),
            "--claude-rules", str(CLAUDE),
            "--design", str(design),
        ])
        ev = root / ".claude" / "skill-authoring" / "test-skill"
        assert DESIGN_TEMPLATE.exists()
        assert DESIGN_REQUIREMENTS_TEMPLATE.exists()
        assert DESIGN_GUIDE.exists()
        assert (ev / "DESIGN_REQUIREMENTS.yaml").exists()
        manifest = json.loads((ev / "RULE_MANIFEST.yaml").read_text(encoding="utf-8"))
        assert manifest["counts"]["rules"] == 89, manifest["counts"]
        assert manifest["counts"]["anti_patterns"] == 26, manifest["counts"]
        assert manifest["counts"]["stage_modules"] == 9, manifest["counts"]

        # Unresolved design requirements and unclassified coverage must fail.
        run([sys.executable, str(VALIDATE), "--project-root", str(root), "--target", "test-skill", "--phase", "spec"], expected=1)

        design_req = json.loads((ev / "DESIGN_REQUIREMENTS.yaml").read_text(encoding="utf-8"))
        for key, entry in design_req["requirements"].items():
            entry["status"] = "RESOLVED"
            if "value" in entry:
                if key == "purpose":
                    entry["value"] = "검증 가능한 테스트 계획을 작성한다."
                elif key == "user_outcome":
                    entry["value"] = "구현 전 실행 가능한 계획을 얻는다."
                else:
                    entry["value"] = f"{key} 요구사항을 해결한다."
            else:
                entry["items"] = [f"{key} 요구사항을 해결한다."]
            entry["sources"] = [str(design)]
        design_req["status"] = "APPROVED"
        dump(ev / "DESIGN_REQUIREMENTS.yaml", design_req)

        spec = json.loads((ev / "COMMAND_SPEC.yaml").read_text(encoding="utf-8"))
        spec.update({
            "purpose": "검증 가능한 테스트 계획을 작성한다.",
            "user_outcome": "구현 전 실행 가능한 계획을 얻는다.",
            "primary_stage": "P",
            "secondary_stages": ["R", "V"],
            "side_effect_level": "local_write",
            "completion_conditions": ["계획과 검증 기준이 존재한다."],
            "status": "APPROVED",
        })
        spec["invocation"] = {"command": "/test-skill", "policy": "manual", "description_strategy": "purpose-bound", "examples": ["/test-skill x"]}
        spec["inputs"] = {"arguments": [], "design_documents": [str(design)], "trusted_sources": [str(design)], "untrusted_sources": []}
        spec["scope"] = {"include": ["plan"], "exclude": ["code changes"], "conditional": []}
        spec["permissions"] = {"allow": ["Read"], "deny": ["Edit"], "approval_required": [], "technical_controls": []}
        spec["execution"] = {"context": "inline", "agent": "", "background": False, "state_length": "single_turn", "working_directory": str(root)}
        spec["outputs"] = {"runtime_files": ["SKILL.md"], "evidence_files": [], "final_report_sections": ["결과"]}
        spec["validation"] = {"structural": ["frontmatter"], "scenario": ["normal"], "trigger_should": [], "trigger_should_not": [], "completion_assertions": ["output exists"]}
        spec["failure_handling"] = {"retryable": [], "non_retryable": ["missing input"], "rollback": [], "stop_conditions": ["missing input"], "partial_success": "report"}
        dump(ev / "COMMAND_SPEC.yaml", spec)

        coverage = json.loads((ev / "RULE_COVERAGE.yaml").read_text(encoding="utf-8"))
        for rid, entry in coverage["rules"].items():
            entry.update({
                "status": "EXCLUDE",
                "rationale": "테스트 픽스처에서는 규칙 추출과 판정 완전성만 검증하므로 런타임 반영 대상이 아니다.",
            })
        coverage["stage_modules"]["primary"] = "P"
        coverage["stage_modules"]["secondary"] = ["R", "V"]
        coverage["stage_modules"]["applied"].update({"P": True, "R": True, "V": True})
        dump(ev / "RULE_COVERAGE.yaml", coverage)
        result = run([sys.executable, str(VALIDATE), "--project-root", str(root), "--target", "test-skill", "--phase", "spec"])
        spec_validation = json.loads(result.stdout)
        assert spec_validation["counts"]["design_requirements"] == 18
        assert spec_validation["counts"]["resolved_design_requirements"] == 18

        skill_dir = root / ".claude" / "skills" / "test-skill"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text("---\ndescription: 테스트 스킬\ndisable-model-invocation: true\n---\n\n# Test\n\n## 목적\n테스트한다.\n", encoding="utf-8")
        for entry in coverage["anti_patterns"].values():
            entry.update({"status": "PASS", "evidence": "테스트 픽스처에서 구조적으로 점검했다."})
        dump(ev / "RULE_COVERAGE.yaml", coverage)
        (ev / "AUTHORING_REVIEW.md").write_text("# Review\n\n## 규칙 집계\n완료\n\n## 문장별 최종 검토\n완료\n\n## 기계 검사 결과\n통과\n", encoding="utf-8")
        run([sys.executable, str(VALIDATE), "--project-root", str(root), "--target", "test-skill", "--phase", "build"])
        (ev / "AUDIT_REPORT.md").write_text("# Audit\n\n## 종합 판정\n- 판정: PASS\n", encoding="utf-8")
        run([sys.executable, str(VALIDATE), "--project-root", str(root), "--target", "test-skill", "--phase", "audit"])
        assert (ev / "FINAL_STATUS.json").exists()

    print("All claude-skill-author package tests passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
