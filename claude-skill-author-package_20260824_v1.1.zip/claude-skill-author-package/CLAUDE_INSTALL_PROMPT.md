# Claude Code에 전달할 일괄 설치 지시문

현재 Claude Code가 열린 Git 저장소 루트에 있는 `claude-skill-author-package_20260824_v1.1.zip`을 설치하라.

1. `git rev-parse --show-toplevel`과 `git status --short`로 저장소 루트와 기존 변경을 확인한다.
2. ZIP이 저장소 루트에 없으면 다른 경로를 추측하거나 다운로드하지 말고 중단한다.
3. 시스템 임시 디렉터리에 압축을 해제한다.
4. 압축 안의 `INSTALL.md`, `install.sh`, `tests/run_tests.py`, 메타 스킬의 `SKILL.md`, `init_authoring.py`, `validate_authoring.py`, `stop_gate.py`를 읽고 다음을 확인한다.
   - 설치 대상이 현재 저장소의 `.claude/` 하위로 제한되는가
   - 네트워크 호출, 커밋, 푸시, 브랜치 변경, 제품 코드 수정이 없는가
   - 기존 파일을 백업하고 `.claude/settings.json`을 자동 수정하지 않는가
5. 예상하지 못한 파괴적 동작이 없으면 압축을 푼 패키지 디렉터리에서 `python3 tests/run_tests.py`를 실행한다.
6. 테스트 종료코드가 0일 때만 `./install.sh "$(git rev-parse --show-toplevel)"`을 실행한다.
7. 다음 설치 결과를 검증한다.
   - `.claude/skills/claude-skill-author/SKILL.md`
   - `.claude/skills/claude-skill-author/assets/DESIGN_INPUT.template.md`
   - `.claude/skills/claude-skill-author/assets/DESIGN_REQUIREMENTS.template.yaml`
   - `.claude/skills/claude-skill-author/references/design-input-guide.md`
   - `.claude/skills/claude-skill-author/scripts/init_authoring.py`
   - `.claude/skills/claude-skill-author/scripts/validate_authoring.py`
   - `.claude/agents/skill-author-auditor.md`
   - `.claude/settings.stop-hook.example.json`
8. Python 스크립트의 구문 검사와 설치 후 `git diff -- .claude`를 확인한다.
9. `.claude/settings.stop-hook.example.json`을 기존 설정에 자동 병합하지 않는다.
10. 커밋·푸시는 수행하지 않는다.

최종 보고에는 설치 성공 여부, 생성·백업 경로, 패키지 테스트 결과, Python 구문 검사 결과, 예상 밖 변경 여부, Claude Code 재시작 필요 여부만 적는다. 이번 요청에서는 `/claude-skill-author`로 다른 스킬을 생성하지 않는다.
